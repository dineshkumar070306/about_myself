/*!
 * script.js — Dineshkumar S Portfolio
 * Combines: theme toggle, nav, hero typing, custom cursor + magnetic
 * buttons, project tabs, certificate modal + scroll reveal, contact
 * form (EmailJS), back-to-top. No dependencies except the EmailJS SDK
 * already loaded in index.html before this file.
 * ───────────────────────────────────────────────────────────────────
 */

/* ═══════════════════════════════════════════════════════════════════
   EMAILJS CONFIG — replace with your own values
   ═══════════════════════════════════════════════════════════════════ */
const EMAILJS_PUBLIC_KEY  = "YOUR_PUBLIC_KEY";   // EmailJS → Account → General
const EMAILJS_SERVICE_ID  = "YOUR_SERVICE_ID";   // EmailJS → Email Services
const EMAILJS_TEMPLATE_ID = "YOUR_TEMPLATE_ID";  // EmailJS → Email Templates


/* ═══════════════════════════════════════════════════════════════════
   1. THEME TOGGLE
   (Initial theme is already set inline in <head> to avoid flash —
   this module just wires up the switch and persists changes.)
   ═══════════════════════════════════════════════════════════════════ */
const ThemeModule = (() => {
  const STORAGE_KEY = "portfolio-theme";
  const root = document.documentElement;

  function applyTheme(theme, animate) {
    if (animate) {
      root.classList.add("theme-transition");
      window.clearTimeout(applyTheme._t);
      applyTheme._t = window.setTimeout(() => root.classList.remove("theme-transition"), 500);
    }
    root.setAttribute("data-theme", theme);
    localStorage.setItem(STORAGE_KEY, theme);
    updateToggleState(theme);
    updateMetaThemeColor(theme);
  }

  function updateMetaThemeColor(theme) {
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.content = theme === "dark" ? "#080b14" : "#f7f8fb";
  }

  function updateToggleState(theme) {
    const btn = document.getElementById("themeToggle");
    if (!btn) return;
    const isDark = theme === "dark";
    btn.setAttribute("aria-checked", String(isDark));
    btn.setAttribute("aria-label", isDark ? "Switch to light mode" : "Switch to dark mode");
  }

  function toggleTheme() {
    const current = root.getAttribute("data-theme");
    applyTheme(current === "dark" ? "light" : "dark", true);
  }

  function watchSystemPreference() {
    const mql = window.matchMedia("(prefers-color-scheme: dark)");
    mql.addEventListener("change", (e) => {
      const explicit = localStorage.getItem(STORAGE_KEY + "-explicit") === "true";
      if (explicit) return;
      applyTheme(e.matches ? "dark" : "light", true);
    });
  }

  function init() {
    updateToggleState(root.getAttribute("data-theme"));
    const btn = document.getElementById("themeToggle");
    if (!btn) return;

    btn.addEventListener("click", () => {
      localStorage.setItem(STORAGE_KEY + "-explicit", "true");
      toggleTheme();
    });
    btn.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        localStorage.setItem(STORAGE_KEY + "-explicit", "true");
        toggleTheme();
      }
    });

    watchSystemPreference();
  }

  return { init };
})();


/* ═══════════════════════════════════════════════════════════════════
   2. MOBILE NAV
   ═══════════════════════════════════════════════════════════════════ */
const NavModule = (() => {
  function init() {
    const burger = document.getElementById("navBurger");
    const links  = document.getElementById("navLinks");
    if (!burger || !links) return;

    burger.addEventListener("click", () => {
      const isOpen = links.classList.toggle("is-open");
      burger.classList.toggle("is-open", isOpen);
      burger.setAttribute("aria-expanded", String(isOpen));
    });

    links.querySelectorAll(".nav__link").forEach((link) => {
      link.addEventListener("click", () => {
        links.classList.remove("is-open");
        burger.classList.remove("is-open");
        burger.setAttribute("aria-expanded", "false");
      });
    });

    /* Highlight active section link on scroll */
    const sections = ["hero", "project", "certs", "connect"]
      .map((id) => document.getElementById(id))
      .filter(Boolean);
    const navLinkMap = new Map();
    links.querySelectorAll(".nav__link").forEach((a) => {
      const id = a.getAttribute("href").replace("#", "");
      navLinkMap.set(id, a);
    });

    if ("IntersectionObserver" in window && sections.length) {
      const io = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              navLinkMap.forEach((a) => a.classList.remove("is-active"));
              const a = navLinkMap.get(entry.target.id);
              if (a) a.classList.add("is-active");
            }
          });
        },
        { rootMargin: "-45% 0px -50% 0px" }
      );
      sections.forEach((s) => io.observe(s));
    }
  }

  return { init };
})();


/* ═══════════════════════════════════════════════════════════════════
   3. HERO TYPING ANIMATION
   ═══════════════════════════════════════════════════════════════════ */
const HeroTypingModule = (() => {
  const phrases = ["AI & ML Enthusiast", "Full Stack Developer", "Problem Solver"];
  let phraseIndex = 0;
  let charIndex = 0;
  let deleting = false;
  const SPEED_TYPE = 80;
  const SPEED_DELETE = 45;
  const PAUSE_END = 1800;
  const PAUSE_START = 400;

  function tick(el) {
    const phrase = phrases[phraseIndex];
    if (!deleting) {
      charIndex++;
      el.textContent = phrase.slice(0, charIndex);
      if (charIndex === phrase.length) {
        deleting = true;
        setTimeout(() => tick(el), PAUSE_END);
        return;
      }
      setTimeout(() => tick(el), SPEED_TYPE);
    } else {
      charIndex--;
      el.textContent = phrase.slice(0, charIndex);
      if (charIndex === 0) {
        deleting = false;
        phraseIndex = (phraseIndex + 1) % phrases.length;
        setTimeout(() => tick(el), PAUSE_START);
        return;
      }
      setTimeout(() => tick(el), SPEED_DELETE);
    }
  }

  function init() {
    const el = document.getElementById("typed-text");
    if (!el) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      el.textContent = phrases[0];
      return;
    }
    setTimeout(() => tick(el), 1200);
  }

  return { init };
})();


/* ═══════════════════════════════════════════════════════════════════
   4. CUSTOM CURSOR + MAGNETIC BUTTONS  (desktop only)
   ═══════════════════════════════════════════════════════════════════ */
const CursorModule = (() => {
  const CFG = {
    trailCount: 8,
    trailDelay: 40,
    ringLerp: 0.12,
    glowLerp: 0.08,
    trailLerp: 0.18,
    magnetStrength: 0.38,
    magnetRadius: 90,
  };

  function make(tag, cls) {
    const el = document.createElement(tag);
    el.className = cls;
    return el;
  }

  function init() {
    if (window.matchMedia("(pointer: coarse)").matches) return;

    document.documentElement.classList.add("has-custom-cursor");

    const dot  = make("div", "cur-dot");
    const ring = make("div", "cur-ring");
    const glow = make("div", "cur-glow");
    const fragment = document.createDocumentFragment();
    fragment.appendChild(glow);
    fragment.appendChild(ring);
    fragment.appendChild(dot);

    const trails = Array.from({ length: CFG.trailCount }, (_, i) => {
      const el = make("div", "cur-trail");
      el.style.opacity = String(1 - i / CFG.trailCount);
      el.style.width = el.style.height = (6 - i * 0.45).toFixed(1) + "px";
      fragment.appendChild(el);
      return { el, x: -200, y: -200 };
    });

    document.body.appendChild(fragment);

    let mouseX = -200, mouseY = -200;
    let dotX = -200, dotY = -200;
    let ringX = -200, ringY = -200;
    let glowX = -200, glowY = -200;
    let hovering = false;
    let clicking = false;
    let onscreen = false;
    let trailTick = 0;
    let trailHead = 0;

    function lerp(a, b, t) { return a + (b - a) * t; }
    function setPos(el, x, y) {
      el.style.transform = `translate(${x.toFixed(1)}px, ${y.toFixed(1)}px) translate(-50%, -50%)`;
    }
    function show() {
      [dot, ring, glow].forEach((el) => el.classList.remove("is-hidden"));
      trails.forEach((t) => (t.el.style.opacity = ""));
    }
    function hide() {
      [dot, ring, glow].forEach((el) => el.classList.add("is-hidden"));
      trails.forEach((t) => (t.el.style.opacity = "0"));
    }
    function syncClasses() {
      dot.classList.toggle("is-hovering", hovering && !clicking);
      ring.classList.toggle("is-hovering", hovering && !clicking);
      glow.classList.toggle("is-hovering", hovering);
      dot.classList.toggle("is-clicking", clicking);
      ring.classList.toggle("is-clicking", clicking);
    }

    document.addEventListener("mousemove", (e) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      if (!onscreen) {
        onscreen = true;
        dotX = ringX = glowX = mouseX;
        dotY = ringY = glowY = mouseY;
        trails.forEach((t) => { t.x = mouseX; t.y = mouseY; });
        show();
      }
    });
    document.addEventListener("mouseleave", () => { onscreen = false; hide(); });
    document.addEventListener("mouseenter", () => { onscreen = true; show(); });
    document.addEventListener("mousedown", () => { clicking = true; syncClasses(); });
    document.addEventListener("mouseup", () => { clicking = false; syncClasses(); });

    const HOVER_SEL = "a, button, [data-magnetic], input, textarea, select, label, [role=button]";
    document.addEventListener("mouseover", (e) => {
      if (e.target.closest(HOVER_SEL)) { hovering = true; syncClasses(); }
    });
    document.addEventListener("mouseout", (e) => {
      if (e.target.closest(HOVER_SEL)) { hovering = false; syncClasses(); }
    });

    /* Magnetic buttons */
    function onMagnetMove(e) {
      const el = e.currentTarget;
      const rect = el.getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      const dx = e.clientX - cx;
      const dy = e.clientY - cy;
      const dist = Math.hypot(dx, dy);
      if (dist < CFG.magnetRadius) {
        const pull = (1 - dist / CFG.magnetRadius) * CFG.magnetStrength;
        el.style.transform = `translate(${dx * pull}px, ${dy * pull}px)`;
      }
    }
    function onMagnetLeave(e) { e.currentTarget.style.transform = "translate(0px, 0px)"; }

    function initMagnetic() {
      document.querySelectorAll("[data-magnetic]").forEach((el) => {
        if (el.dataset.magnetBound) return;
        el.dataset.magnetBound = "true";
        el.addEventListener("mousemove", onMagnetMove);
        el.addEventListener("mouseleave", onMagnetLeave);
      });
    }
    initMagnetic();
    const mo = new MutationObserver(initMagnetic);
    mo.observe(document.body, { childList: true, subtree: true });

    /* RAF loop */
    function loop() {
      requestAnimationFrame(loop);

      dotX = mouseX;
      dotY = mouseY;
      setPos(dot, dotX, dotY);

      ringX = lerp(ringX, mouseX, CFG.ringLerp);
      ringY = lerp(ringY, mouseY, CFG.ringLerp);
      setPos(ring, ringX, ringY);

      glowX = lerp(glowX, mouseX, CFG.glowLerp);
      glowY = lerp(glowY, mouseY, CFG.glowLerp);
      setPos(glow, glowX, glowY);

      trailTick += 16;
      if (trailTick >= CFG.trailDelay) {
        trailTick = 0;
        trailHead = (trailHead - 1 + CFG.trailCount) % CFG.trailCount;
        trails[trailHead].x = dotX;
        trails[trailHead].y = dotY;
      }

      for (let i = 0; i < CFG.trailCount; i++) {
        const idx = (trailHead + i) % CFG.trailCount;
        const prev = trails[(trailHead + i - 1 + CFG.trailCount) % CFG.trailCount];
        if (i > 0) {
          trails[idx].x = lerp(trails[idx].x, prev.x, CFG.trailLerp);
          trails[idx].y = lerp(trails[idx].y, prev.y, CFG.trailLerp);
        }
        setPos(trails[idx].el, trails[idx].x, trails[idx].y);
      }
    }
    requestAnimationFrame(loop);
  }

  return { init };
})();


/* ═══════════════════════════════════════════════════════════════════
   6. SCROLL REVEAL  (used by certificates + section headers)
   ═══════════════════════════════════════════════════════════════════ */
const ScrollRevealModule = (() => {
  function init() {
    const revealEls = document.querySelectorAll("[data-reveal]");
    if (!revealEls.length) return;

    if ("IntersectionObserver" in window) {
      const io = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add("is-visible");
              io.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.15, rootMargin: "0px 0px -40px 0px" }
      );
      revealEls.forEach((el) => io.observe(el));
    } else {
      revealEls.forEach((el) => el.classList.add("is-visible"));
    }
  }

  return { init };
})();


/* ═══════════════════════════════════════════════════════════════════
   7. CERTIFICATE MODAL
   ═══════════════════════════════════════════════════════════════════ */
const CertModalModule = (() => {
  let lastFocused = null;

  function trapFocus(modal, e) {
    const focusable = modal.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
    if (!focusable.length) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  }

  function init() {
    const modal = document.getElementById("certModal");
    if (!modal) return;

    const modalImg = document.getElementById("modalImg");
    const modalTitle = document.getElementById("modalTitle");
    const modalIssuer = document.getElementById("modalIssuer");
    const modalDate = document.getElementById("modalDate");
    const modalDesc = document.getElementById("modalDesc");
    const triggers = document.querySelectorAll("[data-modal-trigger]");
    const closeEls = document.querySelectorAll("[data-modal-close]");

    function onKeydown(e) {
      if (e.key === "Escape") closeModal();
      if (e.key === "Tab") trapFocus(modal, e);
    }

    function openModal(trigger) {
      lastFocused = document.activeElement;

      modalImg.src = trigger.dataset.img || "";
      modalImg.alt = trigger.dataset.title || "Certificate preview";
      modalTitle.textContent = trigger.dataset.title || "";
      modalIssuer.textContent = trigger.dataset.issuer || "";
      modalDate.textContent = trigger.dataset.date || "";
      modalDesc.textContent = trigger.dataset.desc || "";

      modal.hidden = false;
      document.body.classList.add("cert-modal-open");
      requestAnimationFrame(() => modal.classList.add("is-open"));
      modal.querySelector(".cert-modal__close").focus();
      document.addEventListener("keydown", onKeydown);
    }

    function closeModal() {
      modal.classList.remove("is-open");
      document.body.classList.remove("cert-modal-open");
      document.removeEventListener("keydown", onKeydown);

      const panel = modal.querySelector(".cert-modal__panel");
      const onEnd = (e) => {
        if (e.target !== panel) return;
        modal.hidden = true;
        panel.removeEventListener("transitionend", onEnd);
      };
      panel.addEventListener("transitionend", onEnd);

      if (lastFocused) lastFocused.focus();
    }

    triggers.forEach((trigger) => trigger.addEventListener("click", () => openModal(trigger)));
    closeEls.forEach((el) => el.addEventListener("click", closeModal));
  }

  return { init };
})();


/* ═══════════════════════════════════════════════════════════════════
   8. CONTACT FORM  (EmailJS + validation + spam protection)
   ═══════════════════════════════════════════════════════════════════ */
const ContactFormModule = (() => {
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  let formLoadedAt = 0;

  function init() {
    const form = document.getElementById("contactForm");
    if (!form) return;

    if (typeof emailjs !== "undefined") {
      emailjs.init({ publicKey: EMAILJS_PUBLIC_KEY });
    }

    formLoadedAt = Date.now();

    const submitBtn = document.getElementById("submitBtn");
    const statusBox = document.getElementById("formStatus");
    const charCount = document.getElementById("charCount");
    const messageEl = document.getElementById("message");

    const fields = {
      from_name: { el: document.getElementById("from_name"), err: document.getElementById("err-name") },
      reply_to:  { el: document.getElementById("reply_to"),  err: document.getElementById("err-email") },
      subject:   { el: document.getElementById("subject"),   err: document.getElementById("err-subject") },
      message:   { el: document.getElementById("message"),   err: document.getElementById("err-message") },
    };

    messageEl.addEventListener("input", () => {
      const len = messageEl.value.length;
      charCount.textContent = `${len} / 2000`;
      charCount.style.color = len > 1900 ? "var(--red)" : "";
    });

    function validateField(key) {
      const { el, err } = fields[key];
      const value = el.value.trim();
      let message = "";

      if (key === "from_name") {
        if (!value) message = "Please enter your name.";
        else if (value.length < 2) message = "Name looks too short.";
      }
      if (key === "reply_to") {
        if (!value) message = "Please enter your email.";
        else if (!EMAIL_RE.test(value)) message = "Enter a valid email address.";
      }
      if (key === "subject") {
        if (!value) message = "Please add a subject.";
        else if (value.length < 3) message = "Subject looks too short.";
      }
      if (key === "message") {
        if (!value) message = "Please write a message.";
        else if (value.length < 10) message = "Message should be at least 10 characters.";
      }

      const fieldWrap = el.closest(".contact__field");
      if (message) {
        fieldWrap.classList.add("is-invalid");
        fieldWrap.classList.remove("is-valid");
        err.textContent = message;
        return false;
      } else {
        fieldWrap.classList.remove("is-invalid");
        fieldWrap.classList.add("is-valid");
        err.textContent = "";
        return true;
      }
    }

    Object.keys(fields).forEach((key) => {
      const { el } = fields[key];
      el.addEventListener("blur", () => validateField(key));
      el.addEventListener("input", () => {
        if (el.closest(".contact__field").classList.contains("is-invalid")) validateField(key);
      });
    });

    function validateAll() {
      return Object.keys(fields).map(validateField).every(Boolean);
    }

    function showStatus(type, text) {
      statusBox.textContent = text;
      statusBox.className = "contact__status " + (type === "success" ? "is-success" : "is-error");
    }
    function clearStatus() {
      statusBox.textContent = "";
      statusBox.className = "contact__status";
    }
    function setLoading(isLoading) {
      submitBtn.disabled = isLoading;
      submitBtn.classList.toggle("is-loading", isLoading);
      submitBtn.querySelector(".contact__submit-label").textContent = isLoading ? "Sending..." : "Send Message";
    }

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      clearStatus();

      /* Spam protection #1 — honeypot */
      const honeypot = document.getElementById("company").value;
      if (honeypot) {
        showStatus("success", "Thanks! Your message has been sent.");
        form.reset();
        return;
      }

      /* Spam protection #2 — minimum time-on-page */
      const elapsed = Date.now() - formLoadedAt;
      if (elapsed < 3000) {
        showStatus("error", "Please take a moment to fill out the form before sending.");
        return;
      }

      if (!validateAll()) {
        showStatus("error", "Please fix the highlighted fields and try again.");
        return;
      }

      if (typeof emailjs === "undefined") {
        showStatus("error", "Email service failed to load. Please try again or email me directly.");
        return;
      }

      setLoading(true);
      try {
        await emailjs.sendForm(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, form);
        showStatus("success", "Thanks! Your message has been sent — I'll get back to you soon.");
        form.reset();
        charCount.textContent = "0 / 2000";
        Object.values(fields).forEach(({ el }) => el.closest(".contact__field").classList.remove("is-valid", "is-invalid"));
      } catch (error) {
        console.error("EmailJS error:", error);
        showStatus("error", "Something went wrong sending your message. Please try again, or email me directly.");
      } finally {
        setLoading(false);
      }
    });
  }

  return { init };
})();


/* ═══════════════════════════════════════════════════════════════════
   9. BACK TO TOP
   ═══════════════════════════════════════════════════════════════════ */
const BackToTopModule = (() => {
  function init() {
    const btn = document.getElementById("backToTop");
    if (!btn) return;

    let ticking = false;
    window.addEventListener("scroll", () => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        btn.classList.toggle("is-visible", window.scrollY > 600);
        ticking = false;
      });
    });

    btn.addEventListener("click", () => {
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }

  return { init };
})();


/* ═══════════════════════════════════════════════════════════════════
   BOOT
   ═══════════════════════════════════════════════════════════════════ */
document.addEventListener("DOMContentLoaded", () => {
  ThemeModule.init();
  NavModule.init();
  HeroTypingModule.init();
  CursorModule.init();
  ScrollRevealModule.init();
  CertModalModule.init();
  ContactFormModule.init();
  BackToTopModule.init();
});
